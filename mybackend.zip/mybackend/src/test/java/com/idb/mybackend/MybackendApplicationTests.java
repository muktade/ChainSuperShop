package com.idb.mybackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
